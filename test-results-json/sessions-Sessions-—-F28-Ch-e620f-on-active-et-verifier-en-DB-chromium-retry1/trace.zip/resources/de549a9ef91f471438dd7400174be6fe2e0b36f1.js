import{b as m}from"./vendor-query-7w_N4kKk.js";import{supabase as n}from"./supabaseMinimal-TVBfSwS7.js";import{queryKeys as i}from"./queryClient-C9IJlCRf.js";import"./vendor-sonner-DIGN6Nr9.js";async function o(){const{data:e,error:r}=await n.from("squad_members").select(`
      squad_id,
      squads!inner (
        id,
        name,
        game,
        invite_code,
        owner_id,
        total_members,
        created_at
      )
    `);if(r)throw r;if(!e||e.length===0)return[];const t=[...new Set(e.map(a=>a.squad_id))],s=e.map(a=>a.squads);return t.map(a=>s.find(u=>u.id===a)).filter(Boolean).map(a=>({...a,member_count:a.total_members??1})).sort((a,u)=>new Date(u.created_at).getTime()-new Date(a.created_at).getTime())}async function d(e){const{data:r,error:t}=await n.from("squads").select("*").eq("id",e).single();if(t)throw t;const{data:s}=await n.from("squad_members").select("*, profiles(username, avatar_url, reliability_score)").eq("squad_id",e);return{...r,members:s||[],member_count:s?.length??0}}function b(){return m({queryKey:i.squads.list(),queryFn:o,staleTime:30*1e3})}function y(e){return m({queryKey:i.squads.detail(e??""),queryFn:()=>e?d(e):null,enabled:!!e,staleTime:30*1e3})}export{y as a,b as u};
