const s={duration:{slower:.6},easing:{easeOut:[.16,1,.3,1],springSnappy:{type:"spring",stiffness:500,damping:30}}};export{s as m};
